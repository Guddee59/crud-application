export const product = [
    {
        img: "/images/product/1.webp",
        offPrice: "$3789",
        mainPrice: "$2,464",
        productName: "Home Bar 7 Piece Cabinet Set"
    },
    {
        img: "/images/product/2.webp",
        offPrice: "$1699.99",
        mainPrice: "$1,099",
        productName: "Home Bar 3 Piece Cabinet Set"
    }
    ,
    {
        img: "/images/product/3.webp",
        offPrice: "$549.99",
        mainPrice: "$354",
        productName: "Home Bar 2-Door Cabinet - 21"
    }
    ,
    {
        img: "/images/product/4.webp",
        offPrice: "$3789.99",
        mainPrice: "$2,464",
        productName: "Home Bar 7 Piece Cabinet Set"
    }
    ,
    {
        img: "/images/product/5.webp",
        offPrice: "$3,239.99",
        mainPrice: "$2,104.99",
        productName: "Home Bar 7 Piece Cabinet Set"
    }
    ,
    {
        img: "/images/product/6.webp",
        offPrice: "$549.99",
        mainPrice: "$354",
        productName: "Home Bar Tall Wall Cabinet - 21"
    }
]